import numpy as np
import re
from collections import defaultdict
import math

def generate_ngram_statistics(tokens, n):
    total_token_count = len(tokens[1:-1])
    ngram_frequencies = defaultdict(int)
    context_frequencies = defaultdict(int)
    
    for i in range(len(tokens) - n + 1):
        ngram_tuple = tuple(tokens[i:i+n])
        ngram_frequencies[ngram_tuple] += 1
        
        if n > 1:
            context = ngram_tuple[:-1]
            context_frequencies[context] += 1
    
    return ngram_frequencies, context_frequencies, total_token_count

def process_text(input_text, word_stats, start_token="<BEGIN>", end_token="</FINISH>", unk_token="<UNKNOWN>", apply_unknown=True):
    input_text = input_text.lower()
    input_text = re.sub(r'\s+', ' ', input_text)
    input_text = re.sub(r'[^\w\s]', '', input_text)
    tokens = input_text.split()
    tokens = [start_token] + tokens + [end_token]
    
    if apply_unknown:
        tokens = [unk_token if word not in word_stats else word for word in tokens]
        
    return tokens

def create_vocabulary(corpus, min_frequency, start_token="<BEGIN>", end_token="</FINISH>", unk_token="<UNKNOWN>"):
    word_stats = defaultdict(int)
    
    for document in corpus:
        tokens = process_text(document, word_stats, apply_unknown=False)
        for token in tokens:
            word_stats[token] += 1
    
    word_stats[unk_token] = 0
    for token in list(word_stats.keys()):
        if token not in [start_token, end_token, unk_token] and word_stats[token] < min_frequency:
            word_stats[unk_token] += word_stats.pop(token)
    
    return word_stats

def calculate_probability(ngram, ngram_frequencies, context_frequencies, vocab_size, smoothing_type="ngram", k_value=1.0):
    if smoothing_type == "ngram":
        denominator = context_frequencies[ngram[:-1]] if len(ngram) > 1 else sum(ngram_frequencies.values())
        return ngram_frequencies[ngram] / denominator if denominator > 0 else 0
    elif smoothing_type == "laplace":
        denominator = context_frequencies[ngram[:-1]] if len(ngram) > 1 else sum(ngram_frequencies.values())
        return (ngram_frequencies[ngram] + 1) / (denominator + vocab_size)
    elif smoothing_type == "add-k":
        denominator = context_frequencies[ngram[:-1]] if len(ngram) > 1 else sum(ngram_frequencies.values())
        return (ngram_frequencies[ngram] + k_value) / (denominator + k_value * vocab_size)
    else:
        raise ValueError(f"Unknown smoothing method: {smoothing_type}")

def evaluate_perplexity(dataset, ngram_frequencies, context_frequencies, vocab_size, word_stats, smoothing_type="ngram", n=2, k_value=1.0):
    log_prob_sum = 0
    word_count = 0

    for sentence in dataset:
        tokens = process_text(sentence, word_stats)
        log_prob = 0
        
        for i in range(n-1, len(tokens)):
            ngram_tuple = tuple(tokens[max(0, i - n + 1):i+1])
            prob = calculate_probability(ngram_tuple, ngram_frequencies, context_frequencies, vocab_size, smoothing_type, k_value)
            log_prob += math.log(prob) if prob > 0 else float('-inf')
        
        log_prob_sum += log_prob
        word_count += len(tokens) - 2

    avg_log_prob = log_prob_sum / word_count
    perplexity = math.exp(-avg_log_prob)
    return perplexity

with open('./data/train.txt', 'r', encoding='utf-8') as train_file:
    training_data = train_file.readlines()

with open('./data/val.txt', 'r', encoding='utf-8') as val_file:
    validation_data = val_file.readlines()

def run_analysis():
    unknown_token_thresholds = [2, 3]
    vocab_info = []
    
    for threshold in unknown_token_thresholds:
        print(f"Evaluating with Missing Token Threshold: {threshold}")
        
        word_stats = create_vocabulary(training_data, threshold)
        tokenized_train = [process_text(sentence.strip(), word_stats) for sentence in training_data]
        vocab_size = len(word_stats)
        vocab_info.append(vocab_size)
        print(f"Total Vocabulary Size: {vocab_size}")

        unigram_frequencies, _, unigram_total = generate_ngram_statistics([token for sentence in tokenized_train for token in sentence], 1)
        bigram_frequencies, bigram_context_frequencies, _ = generate_ngram_statistics([token for sentence in tokenized_train for token in sentence], 2)

        k_values = [0.001, 0.01, 0.1]

        for k in k_values:
            print(f"Testing with Smoothing Factor k = {k}")
            
            unigram_train_perplexity = evaluate_perplexity(training_data, unigram_frequencies, {}, vocab_size, word_stats, "add-k", n=1, k_value=k)
            bigram_train_perplexity = evaluate_perplexity(training_data, bigram_frequencies, bigram_context_frequencies, vocab_size, word_stats, "add-k", n=2, k_value=k)
            unigram_val_perplexity = evaluate_perplexity(validation_data, unigram_frequencies, {}, vocab_size, word_stats, "add-k", n=1, k_value=k)
            bigram_val_perplexity = evaluate_perplexity(validation_data, bigram_frequencies, bigram_context_frequencies, vocab_size, word_stats, "add-k", n=2, k_value=k)

            print(f"Unigram Perplexity (Train) - Add-k Smoothing: {unigram_train_perplexity:.2f}")
            print(f"Bigram Perplexity (Train) - Add-k Smoothing: {bigram_train_perplexity:.2f}")
            print(f"Unigram Perplexity (Validation) - Add-k Smoothing: {unigram_val_perplexity:.2f}")
            print(f"Bigram Perplexity (Validation) - Add-k Smoothing: {bigram_val_perplexity:.2f}")

        print("\nTesting Laplace Smoothing:")
        unigram_train_perplexity = evaluate_perplexity(training_data, unigram_frequencies, {}, vocab_size, word_stats, "laplace", n=1)
        bigram_train_perplexity = evaluate_perplexity(training_data, bigram_frequencies, bigram_context_frequencies, vocab_size, word_stats, "laplace", n=2)
        unigram_val_perplexity = evaluate_perplexity(validation_data, unigram_frequencies, {}, vocab_size, word_stats, "laplace", n=1)
        bigram_val_perplexity = evaluate_perplexity(validation_data, bigram_frequencies, bigram_context_frequencies, vocab_size, word_stats, "laplace", n=2)

        print(f"Unigram Perplexity (Train) - Laplace Smoothing: {unigram_train_perplexity:.2f}")
        print(f"Bigram Perplexity (Train) - Laplace Smoothing: {bigram_train_perplexity:.2f}")
        print(f"Unigram Perplexity (Validation) - Laplace Smoothing: {unigram_val_perplexity:.2f}")
        print(f"Bigram Perplexity (Validation) - Laplace Smoothing: {bigram_val_perplexity:.2f}")

        print("\nRunning Maximum Likelihood Estimation (No Smoothing):")
        unigram_train_perplexity = evaluate_perplexity(training_data, unigram_frequencies, {}, vocab_size, word_stats, "ngram", n=1)
        bigram_train_perplexity = evaluate_perplexity(training_data, bigram_frequencies, bigram_context_frequencies, vocab_size, word_stats, "ngram", n=2)
        unigram_val_perplexity = evaluate_perplexity(validation_data, unigram_frequencies, {}, vocab_size, word_stats, "ngram", n=1)
        bigram_val_perplexity = evaluate_perplexity(validation_data, bigram_frequencies, bigram_context_frequencies, vocab_size, word_stats, "ngram", n=2)

        print(f"Unigram Perplexity (Train) - No Smoothing: {unigram_train_perplexity:.2f}")
        print(f"Bigram Perplexity (Train) - No Smoothing: {bigram_train_perplexity:.2f}")
        print(f"Unigram Perplexity (Validation) - No Smoothing: {unigram_val_perplexity:.2f}")
        print(f"Bigram Perplexity (Validation) - No Smoothing: {bigram_val_perplexity:.2f}\n")

if __name__ == "__main__":
    run_analysis()
